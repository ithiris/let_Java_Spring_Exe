public class Current {

    public Current(){

    }
}
