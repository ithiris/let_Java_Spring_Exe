public class Savings {
    private double interestRate = 0.8;

    // Default constructor
    public Savings (){

    }
    public void Withdraw(double amount){

    }
   public void Deposit(double amount){

    }
    public void  printBalance() {

    }
}
