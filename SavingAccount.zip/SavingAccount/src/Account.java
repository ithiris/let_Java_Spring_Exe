public class Account {
    protected double balance;

    public void Withdraw(double amount){

    }
    public void Deposit(double amount) {

    }
    public void printBalance(){

    }
}
